<template>
  <span class="badge text-danger">required!</span>
</template>

<script>
export default {
  name: 'ValidateMessage',
}
</script>

<style scoped></style>
