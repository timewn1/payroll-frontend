<template>
  <div class="row justify-content-center">Loading...</div>
</template>

<script>
export default {
  name: 'DefaultLoading',
}
</script>

<style scoped></style>
