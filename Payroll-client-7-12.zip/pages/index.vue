<template>
  <Login />
</template>

<script>
export default {
  layout: 'login',
}
</script>

<style scoped></style>
