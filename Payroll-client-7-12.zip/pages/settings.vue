<template>
  <Settings />
</template>

<script>
export default {
  name: 'settings',
  layout: 'dashboard',
}
</script>

<style scoped></style>
