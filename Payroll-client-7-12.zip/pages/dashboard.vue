<template>
  <Dashboard />
</template>

<script>
export default {
  name: 'dashboard',
  layout: 'dashboard',
}
</script>

<style scoped></style>
