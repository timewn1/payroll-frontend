<template>
  <AddCalendar />
</template>

<script>
export default {
  name: 'add',
  layout: 'dashboard',
}
</script>

<style scoped></style>
