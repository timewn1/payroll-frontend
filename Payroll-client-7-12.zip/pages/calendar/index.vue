<template>
  <Calender />
</template>

<script>
export default {
  name: 'calender',
  layout: 'dashboard',
}
</script>

<style scoped></style>
