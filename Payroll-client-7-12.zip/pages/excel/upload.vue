<template>
  <UploadExcel />
</template>

<script>
export default {
  name: 'excel',
  layout: 'dashboard',
}
</script>

<style scoped></style>
