<template>
  <DownloadExcel />
</template>

<script>
export default {
  name: 'index',
  layout: 'dashboard',
}
</script>

<style scoped></style>
