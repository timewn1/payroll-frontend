<template>
  <Employees />
</template>

<script>
import Employees from '~/components/Employees'
export default {
  name: 'index',
  components: { Employees },
  layout: 'dashboard',
}
</script>

<style scoped></style>
