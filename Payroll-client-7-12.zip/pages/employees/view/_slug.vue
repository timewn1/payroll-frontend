<template>
  <ViewEmployee />
</template>

<script>
export default {
  name: '_slug',
  layout: 'dashboard',
}
</script>

<style scoped></style>
