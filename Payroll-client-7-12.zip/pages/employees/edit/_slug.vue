<template>
  <EditEmployee />
</template>

<script>
export default {
  name: '_edit',
  layout: 'dashboard',
}
</script>

<style scoped></style>
