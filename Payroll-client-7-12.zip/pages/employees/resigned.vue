<template>
  <ResignedEmployees />
</template>

<script>
import ResignedEmployees from '~/components/ResignedEmployees'
export default {
  name: 'resigned',
  components: { ResignedEmployees },
  layout: 'dashboard',
}
</script>

<style scoped></style>
