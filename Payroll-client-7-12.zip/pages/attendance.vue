<template>
  <Attendance />
</template>

<script>
export default {
  name: 'attendance',
  layout: 'dashboard',
}
</script>

<style scoped></style>
