<template>
  <Nuxt />
</template>

<script>
export default {
  name: 'login',
}
</script>

<style scoped></style>
